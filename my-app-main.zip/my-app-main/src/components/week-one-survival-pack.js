import React, {Component} from 'react';

class WeekOneSurvivalPack extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        <h1>Week One Survival Pack</h1>
      </div>
    );
  }
}

export default WeekOneSurvivalPack;
