import React, {Component} from 'react';

class UniversityExpectations extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        <h1>University Expecations</h1>
      </div>
    );
  }
}

export default UniversityExpectations;
